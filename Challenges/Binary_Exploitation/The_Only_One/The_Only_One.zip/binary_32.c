#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TEAM_SIZE 8

const int goal = 400;

struct team 
{
    char* names[MAX_TEAM_SIZE];
    char* power;
    int teamSize;
};

typedef struct team team;

void match(char* powers, int teamSize) 
{
	int i = 0;
    int sum = 0;
    for(i = 0; i < teamSize; ++i) 
    {
        sum += powers[i];
    }

    if(sum == goal) 
    {
        printf("Wow! Your team is strong! Here, take this flag:\n");
        setuid(0);
        system("/bin/cat ./flag.txt");
    } 
    else 
    {
        printf("Your team had %d power, but you needed exactly %d!\n", sum, goal);
    }
}

char input[256];

int main(int argc, char** argv) 
{

    gid_t gid = getegid();
    setresgid(gid, gid, gid);

    setbuf(stdout, NULL);

    team t;

    t.teamSize = 0;
    t.power = malloc(sizeof(char) * MAX_TEAM_SIZE);

    printf("Commands:\n A <name> - Add a team member\n M - Start the match\n Q - Quit\n");

    while(1) 
    {
        fgets(input, 255, stdin); // no overflow here sry
        input[strcspn(input, "\n")] = '\0';
        if(input[0] == 'A') 
        {
            if(t.teamSize > MAX_TEAM_SIZE) 
            {
                printf("Your team is too large!\n");
            } 
            else 
            {
                t.power[t.teamSize] = rand() % 10;
                char* newMember = (char*) malloc(256);
                strcpy(newMember, &input[2]);
                t.names[t.teamSize] = newMember;
                t.teamSize++;
                free(newMember);
            }
        } 
        else if (input[0] == 'M') 
        {
            match(t.power, t.teamSize);
        } 
        else if (input[0] == 'Q') 
        {
            printf("Thanks for playing!\n");
            return 0;
        } 
        else 
        {
            printf("Try again\n");
        }
    }
}

