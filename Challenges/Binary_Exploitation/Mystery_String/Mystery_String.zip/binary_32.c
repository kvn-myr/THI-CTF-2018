#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int secret = 0;

//TODO: Ask IT why this is here
void win()
{
    system("/bin/cat ./flag.txt");
}

int main(int argc, char** argv)
{
    char buf[128];
    memset(buf, 0, sizeof(buf));
    fgets(buf, 128, stdin);
    printf(buf);

    if (secret == 192)
    {
        win();
    }
    else
    {
        printf("Sorry, secret = %d\n", secret);
    }

    return 0;
}
