#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>

#define BYTES 10

// What the hell is this ?
void win()
{
    system("/bin/cat ./flag.txt");    
}

// strange thing, but what do I know ?
void vuln()
{
    char* something = (char *)mmap(NULL, BYTES, PROT_EXEC|PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, 0, 0);
    if(something == MAP_FAILED){
        printf("Oops!? Please talk to admin\n");
        exit(0);
    }
    printf("So, you have %d bytes free, use it wisely:\n", BYTES);
    fflush(stdout);
    int input = read(STDIN_FILENO, something, BYTES);
    if(input == 0){
        printf("Nothing to do!");
        exit(0);
    }
    void (*good_or_evil)() = (void (*)())something;
    good_or_evil();      
}

int main(int argc, char** argv)
{
    printf("I don't know what to do myself, but you can manage that, I am sure!\n");
    fflush(stdout);
    vuln();
    return 0;
}
